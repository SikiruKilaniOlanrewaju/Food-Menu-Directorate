# Food-Menu-Directorate-System
The Food Menu Directorates is an enlightenment System which will help the users to know how to cook some dishes and this particular software based on Yoruba Dishes 
